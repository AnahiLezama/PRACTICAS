// Inicializar el mapa centrado en Aguascalientes 
var map = L.map('map').setView([21.88234, -102.28259], 13); // Coordenadas de Aguascalientes 
// Añadir capa de OpenStreetMap 
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { 
maxZoom: 19, 
attribution: '© OpenStreetMap' 
}).addTo(map); 